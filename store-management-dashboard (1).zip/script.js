// This file is deprecated and no longer used.
// The application logic has been migrated to React components (.tsx files).
